-- Generado por Oracle SQL Developer Data Modeler 24.3.1.351.0831
--   en:        2026-09-13 01:14:12 CLST
--   sitio:      Oracle Database 11g
--   tipo:      Oracle Database 11g



-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

-- predefined type, no DDL - XMLTYPE

CREATE TABLE BOLETA 
    ( 
     numero_boleta      NUMBER (10)  NOT NULL , 
     fecha_venta        DATE  NOT NULL , 
     monto_total        NUMBER  NOT NULL , 
     CLIENTE_id_cliente NUMBER (10)  NOT NULL 
    ) 
;

ALTER TABLE BOLETA 
    ADD CONSTRAINT BOLETA_PK PRIMARY KEY ( numero_boleta ) ;

CREATE TABLE CATEGORIA 
    ( 
     id_categoria         NUMBER (10)  NOT NULL , 
     nombre_categoria     VARCHAR2 (20)  NOT NULL , 
     PRODUCTO_id_producto NUMBER (10)  NOT NULL 
    ) 
;

ALTER TABLE CATEGORIA 
    ADD CONSTRAINT CATEGORIA_PK PRIMARY KEY ( id_categoria ) ;

CREATE TABLE CLIENTE 
    ( 
     id_cliente        NUMBER (10)  NOT NULL , 
     nombre_completo   VARCHAR2 (30)  NOT NULL , 
     telefono          NUMBER (20)  NOT NULL , 
     COMUNA_cod_comuna NUMBER (10)  NOT NULL 
    ) 
;

ALTER TABLE CLIENTE 
    ADD CONSTRAINT CLIENTE_PK PRIMARY KEY ( id_cliente ) ;

CREATE TABLE COMUNA 
    ( 
     cod_comuna NUMBER (10)  NOT NULL , 
     nombre     VARCHAR2 (20)  NOT NULL , 
     cod_region NUMBER (10)  NOT NULL 
    ) 
;

ALTER TABLE COMUNA 
    ADD CONSTRAINT COMUNA_PK PRIMARY KEY ( cod_comuna ) ;

CREATE TABLE DETALLE_VENTA 
    ( 
     cantidad             NUMBER (3)  NOT NULL , 
     precio               NUMBER (6)  NOT NULL , 
     BOLETA_numero_boleta NUMBER (10)  NOT NULL , 
     PRODUCTO_id_producto NUMBER (10)  NOT NULL 
    ) 
;

ALTER TABLE DETALLE_VENTA 
    ADD CONSTRAINT DETALLE_VENTA_PK PRIMARY KEY ( BOLETA_numero_boleta, PRODUCTO_id_producto ) ;

CREATE TABLE EMPRESA 
    ( 
     rut     VARCHAR2 (20)  NOT NULL , 
     nombre  VARCHAR2 (20)  NOT NULL , 
     website VARCHAR2 (100) 
    ) 
;

ALTER TABLE EMPRESA 
    ADD CONSTRAINT EMPRESA_PK PRIMARY KEY ( rut ) ;

CREATE TABLE MARCA 
    ( 
     id_marca NUMBER (10)  NOT NULL 
    ) 
;

ALTER TABLE MARCA 
    ADD CONSTRAINT MARCA_PK PRIMARY KEY ( id_marca ) ;

CREATE TABLE MODELO 
    ( 
     id_modelo      NUMBER (10)  NOT NULL , 
     descripcion    VARCHAR2 (100)  NOT NULL , 
     MARCA_id_marca NUMBER (10)  NOT NULL 
    ) 
;

ALTER TABLE MODELO 
    ADD CONSTRAINT MODELO_PK PRIMARY KEY ( id_modelo, MARCA_id_marca ) ;

CREATE TABLE PERSONA_NATURAL 
    ( 
     rut       VARCHAR2 (20)  NOT NULL , 
     nombres   VARCHAR2 (20)  NOT NULL , 
     apellidos VARCHAR2 (20)  NOT NULL 
    ) 
;

ALTER TABLE PERSONA_NATURAL 
    ADD CONSTRAINT PERSONA_NATURAL_PK PRIMARY KEY ( rut ) ;

CREATE TABLE PRODUCTO 
    ( 
     id_producto            NUMBER (10)  NOT NULL , 
     nombre_producto        VARCHAR2 (20)  NOT NULL , 
     descripcion            VARCHAR2 (100)  NOT NULL , 
     precio_venta           NUMBER (6)  NOT NULL , 
     fecha_vencimiento      DATE , 
     SUCURSAL_sigla         VARCHAR2 (10)  NOT NULL , 
     CATEGORIA_id_categoria NUMBER (10)  NOT NULL , 
     MODELO_id_modelo       NUMBER (10)  NOT NULL , 
     MODELO_MARCA_id_marca  NUMBER (10)  NOT NULL 
    ) 
;

ALTER TABLE PRODUCTO 
    ADD CONSTRAINT PRODUCTO_PK PRIMARY KEY ( id_producto ) ;

CREATE TABLE PROVEEDOR 
    ( 
     rut            VARCHAR2 (20)  NOT NULL , 
     dv             VARCHAR2 (20)  NOT NULL , 
     telefono       NUMBER (20)  NOT NULL , 
     direccion      VARCHAR2 (30)  NOT NULL , 
     email          VARCHAR2 (20)  NOT NULL , 
     tipo_proveedor VARCHAR2 (20)  NOT NULL 
    ) 
;

ALTER TABLE PROVEEDOR 
    ADD CONSTRAINT PROVEEDOR_PK PRIMARY KEY ( rut ) ;

CREATE TABLE SUCURSAL 
    ( 
     sigla             VARCHAR2 (10)  NOT NULL , 
     nombre            VARCHAR2 (20)  NOT NULL , 
     COMUNA_cod_comuna NUMBER (10)  NOT NULL 
    ) 
;

ALTER TABLE SUCURSAL 
    ADD CONSTRAINT SUCURSAL_PK PRIMARY KEY ( sigla ) ;

CREATE TABLE SUMINISTRO 
    ( 
     PRODUCTO_id_producto NUMBER (10)  NOT NULL , 
     PROVEEDOR_rut        VARCHAR2 (20)  NOT NULL 
    ) 
;

ALTER TABLE SUMINISTRO 
    ADD CONSTRAINT SUMINISTRO_PK PRIMARY KEY ( PRODUCTO_id_producto, PROVEEDOR_rut ) ;

ALTER TABLE BOLETA 
    ADD CONSTRAINT BOLETA_CLIENTE_FK FOREIGN KEY 
    ( 
     CLIENTE_id_cliente
    ) 
    REFERENCES CLIENTE 
    ( 
     id_cliente
    ) 
;

ALTER TABLE CATEGORIA 
    ADD CONSTRAINT CATEGORIA_PRODUCTO_FK FOREIGN KEY 
    ( 
     PRODUCTO_id_producto
    ) 
    REFERENCES PRODUCTO 
    ( 
     id_producto
    ) 
;

ALTER TABLE CLIENTE 
    ADD CONSTRAINT CLIENTE_COMUNA_FK FOREIGN KEY 
    ( 
     COMUNA_cod_comuna
    ) 
    REFERENCES COMUNA 
    ( 
     cod_comuna
    ) 
;

ALTER TABLE DETALLE_VENTA 
    ADD CONSTRAINT DETALLE_VENTA_BOLETA_FK FOREIGN KEY 
    ( 
     BOLETA_numero_boleta
    ) 
    REFERENCES BOLETA 
    ( 
     numero_boleta
    ) 
;

ALTER TABLE DETALLE_VENTA 
    ADD CONSTRAINT DETALLE_VENTA_PRODUCTO_FK FOREIGN KEY 
    ( 
     PRODUCTO_id_producto
    ) 
    REFERENCES PRODUCTO 
    ( 
     id_producto
    ) 
;

ALTER TABLE EMPRESA 
    ADD CONSTRAINT EMPRESA_PROVEEDOR_FK FOREIGN KEY 
    ( 
     rut
    ) 
    REFERENCES PROVEEDOR 
    ( 
     rut
    ) 
;

ALTER TABLE MODELO 
    ADD CONSTRAINT MODELO_MARCA_FK FOREIGN KEY 
    ( 
     MARCA_id_marca
    ) 
    REFERENCES MARCA 
    ( 
     id_marca
    ) 
;

ALTER TABLE PERSONA_NATURAL 
    ADD CONSTRAINT PERSONA_NATURAL_PROVEEDOR_FK FOREIGN KEY 
    ( 
     rut
    ) 
    REFERENCES PROVEEDOR 
    ( 
     rut
    ) 
;

ALTER TABLE PRODUCTO 
    ADD CONSTRAINT PRODUCTO_CATEGORIA_FK FOREIGN KEY 
    ( 
     CATEGORIA_id_categoria
    ) 
    REFERENCES CATEGORIA 
    ( 
     id_categoria
    ) 
;

ALTER TABLE PRODUCTO 
    ADD CONSTRAINT PRODUCTO_MODELO_FK FOREIGN KEY 
    ( 
     MODELO_id_modelo,
     MODELO_MARCA_id_marca
    ) 
    REFERENCES MODELO 
    ( 
     id_modelo,
     MARCA_id_marca
    ) 
;

ALTER TABLE PRODUCTO 
    ADD CONSTRAINT PRODUCTO_SUCURSAL_FK FOREIGN KEY 
    ( 
     SUCURSAL_sigla
    ) 
    REFERENCES SUCURSAL 
    ( 
     sigla
    ) 
;

ALTER TABLE SUCURSAL 
    ADD CONSTRAINT SUCURSAL_COMUNA_FK FOREIGN KEY 
    ( 
     COMUNA_cod_comuna
    ) 
    REFERENCES COMUNA 
    ( 
     cod_comuna
    ) 
;

ALTER TABLE SUMINISTRO 
    ADD CONSTRAINT SUMINISTRO_PRODUCTO_FK FOREIGN KEY 
    ( 
     PRODUCTO_id_producto
    ) 
    REFERENCES PRODUCTO 
    ( 
     id_producto
    ) 
;

ALTER TABLE SUMINISTRO 
    ADD CONSTRAINT SUMINISTRO_PROVEEDOR_FK FOREIGN KEY 
    ( 
     PROVEEDOR_rut
    ) 
    REFERENCES PROVEEDOR 
    ( 
     rut
    ) 
;

--  ERROR: No Discriminator Column found in Arc FKArc_1 - constraint trigger for Arc cannot be generated 

--  ERROR: No Discriminator Column found in Arc FKArc_1 - constraint trigger for Arc cannot be generated



-- Informe de Resumen de Oracle SQL Developer Data Modeler: 
-- 
-- CREATE TABLE                            13
-- CREATE INDEX                             0
-- ALTER TABLE                             27
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   0
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- 
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
-- 
-- ERRORS                                   2
-- WARNINGS                                 0
